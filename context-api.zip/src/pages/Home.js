import React, { useState, useEffect, useContext } from "react";
import AuthContext from "../context/AuthContext";
import { Table, Col, Row } from "antd";

const Home = () => {
  let [books, setBooks] = useState([]);
  let { authTokens, logOutUser } = useContext(AuthContext);

  useEffect(() => {
    getBooks();
  }, []);

  let getBooks = async () => {
    let response = await fetch("http://localhost:8000/api/books/", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + String(authTokens.access),
      },
    });
    let data = await response.json();
    if (response.status === 200) {
      console.log(data);
      setBooks(data);
    } else if (response.statusText === "Unauthorized") {
      logOutUser();
    }
  };
  const dataSource = books;

  const columns = [
    {
      title: "ID",
      dataIndex: "id",
      key: "id",
    },
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
    },
    {
      title: "Author",
      dataIndex: "author",
      key: "author",
    },
  ];

  return (
    <div>
      <Row justify='center'>
        <Col span={12}>
          <Table dataSource={dataSource} columns={columns} rowKey='id'/>
        </Col>
      </Row>
    </div>
  );
};

export default Home;
